const resultContainer = document.querySelector(`.result-container`)
const loadTalentBtn = document.querySelector(`.load-talents`)

function loadTalent(){
fetch('http://localhost:3000/resources')
  .then(function(response){
return response.json()
})
.then(function(talent){
  talent.foreach(function(talent){
    const div =document.createElement('div');
    div.innerHTML=talent.name
    resultContainer.appendChild(div);
  })
})
}
// loadTalentBtn.addEventListener('onclick', function(){
//   resultContainer.innerHTML ='talent'
//   loadTalent()
// })